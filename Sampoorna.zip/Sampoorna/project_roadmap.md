# Project Roadmap

This product roadmap is a collection of milestones and tasks that will help you get started with the product. We will be adding more milestones and tasks as we go along.

The app , Sampoorna, is a mobile application that helps women in their day to day life, and in case of some emergency, help them by alerting others.

## Milestones

Up till now , we are working on two major features of the app:

- <b> SOS feature</b>
This feature helps women to alert others in case of emergency , by sending an SOS message that carries their location URL to selected contacs.

- <b>Track Mensuration Cycle</b> 
As the name suggests , this features let women save their last mensuration date and track it and alert them in case the date is delayed.
This way they can take better care of their health.

## Ideas for the future 

- To continuously modify both features and making them more useful and more applicable to more people.
- Add a Covid tracker using Google and Apple's API for Exposure Notifications.
- Add blogs feature to the app, that can help women in various aspects.

